﻿You may try «Clink» - bash style autocomplete
Download and unpack files to this folder

http://mridgers.github.io/clink/

Note! Clink distribution has subfolders.
Files must be located in THIS folder exactly:

  clink.bat
  clink_x64.exe
  clink_x86.exe
  clink_dll_x64.dll
  clink_dll_x86.dll

If you install clink in any other folder,
ConEmu will not be able to control clink
loading from ConEmu's settings dialog:
Settings -> Features -> Use clink in prompt
